// menginisialisasi firebase
export const firebaseConfig = {
    apiKey: "AIzaSyBFdO769tH_WExNYs87KXiO7_XQuhnjtWk",
    authDomain: "fir-apps-b3b76.firebaseapp.com",
    databaseURL: "https://fir-apps-b3b76.firebaseio.com",
    projectId: "fir-apps-b3b76",
    storageBucket: "fir-apps-b3b76.appspot.com",
    messagingSenderId: "424200310236"
};