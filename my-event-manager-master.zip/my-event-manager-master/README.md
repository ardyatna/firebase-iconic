# my-event-manager
Firebase Services App powered by Ionic Framework.
