export const firebaseConfig = {
    apiKey: "AIzaSyC_HJzNdJKKdWtPDSXWJlu_joXmIhkPgQU",
    authDomain: "project-firebase-f28f5.firebaseapp.com",
    databaseURL: "https://project-firebase-f28f5.firebaseio.com",
    projectId: "project-firebase-f28f5",
    storageBucket: "project-firebase-f28f5.appspot.com",
    messagingSenderId: "529154349639"
}